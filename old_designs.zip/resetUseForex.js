<div onClick={this.handleResetUseForex}>
  Reset useForex
</div>

@bind
private handleResetUseForex() {
  this.props.setUseForex(false);
}
